import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.text.SimpleDateFormat;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;


public class DurationBetweenTwoDatesMain
{
	public static void main(String args[])
	{
		DurationBetweenTwoDates durationBetweenDate=new DurationBetweenTwoDates();
		durationBetweenDate.checkDuration();
	}
}
