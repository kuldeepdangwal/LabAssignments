

import java.util.Scanner;
import java.util.Arrays;

public class sortStringObjectsMain
{
	public static void main(String args[])
	{
		sortStringObjects sortString=new sortStringObjects();
		sortString.sortstrings();
	}

}