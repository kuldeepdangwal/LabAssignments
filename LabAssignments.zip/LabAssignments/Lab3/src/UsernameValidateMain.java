import java.util.Scanner;
public class UsernameValidateMain
{
	public static void main(String agrs[])
	{
		UsernameValidate validate=new  UsernameValidate();
		validate.validateUsername();
	}
	
}
