package com.cg.squares.client;
import java.util.HashMap;
import java.util.Scanner;
import com.cg.squares.services.FindSquares;
public class MainClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of elements want in array.");
		int noOfElement = sc.nextInt();
		int numbersArray[]= new int[noOfElement];
		System.out.println("Please enter the elements. ");
		for(int i=0;i<noOfElement;i++){
			System.out.println("element" + i);
			numbersArray[i]=sc.nextInt();
		}
		FindSquares fs = new FindSquares();
		HashMap<Integer,Integer> result = fs.getSquare(numbersArray);
		System.out.println("Squares are-: "); 
		System.out.println(result.values());
	}
}
