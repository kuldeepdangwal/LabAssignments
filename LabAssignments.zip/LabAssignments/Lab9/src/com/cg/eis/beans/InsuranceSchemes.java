package com.cg.eis.beans;
public enum InsuranceSchemes
{
	SchemeA,SchemeB,SchemeC,NoSchemes;
}
