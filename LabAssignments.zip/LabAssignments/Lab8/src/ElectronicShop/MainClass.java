package ElectronicShop;
public class MainClass{
	public static void main(String[] args) {
		 ElectronicInterShopCommunication resource = new  ElectronicInterShopCommunication();
		Thread th1 = new Thread(resource,"Customer");
		Thread th2 = new Thread(resource,"BillingPerson");
		try {
			th2.start();
			th1.join();
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		th1.start();
	}
}
