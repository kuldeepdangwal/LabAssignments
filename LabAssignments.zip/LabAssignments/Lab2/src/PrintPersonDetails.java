
public class PrintPersonDetails 
{
	public static void main(String args[])
	{
		String firstname="Divya";
		String lastname="Bharathi";
		char gender='M';
		int age=20;
		double weight=85.55;
		
		System.out.println("Person Details:");
		System.out.println("______________");
		System.out.println("First Name: "+firstname);
		System.out.println("Last Name: "+lastname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
		
		
		
	}
}
